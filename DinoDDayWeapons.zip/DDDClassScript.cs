using System;
using System.Collections.Generic;
using System.Text;

namespace Tests
{
    class DDDClassScript
    {
        public string printname { get; set; }
        public string playermodel { get; set; }
        public string selectcmd { get; set; }
        
        public string team { get; set; }
        
        public string primaryweapon { get; set; }
        public string secondaryweapon { get; set; }
        public string meleeweapon { get; set; }

        public string grenadetype { get; set; }
        public string numgrens { get; set; }

        public string limitcvar { get; set; }

        public string classimage { get; set; }
        public string classimagebg { get; set; }

        public string armor { get; set; }

        public string RunSpeed { get; set; }
        public string SprintSpeed { get; set; }

        public string ThirdPersonView { get; set; }
    }
}
